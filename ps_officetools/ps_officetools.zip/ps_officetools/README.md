# .NetFrameworkAPI利用Office系アプリケーション操作支援PowerShell
## Outlook受信メールフォルダ内アイテム取得用スクリプトサンプル

---
本スクリプトは.NetFrameworkモジュールを使用したOutlookメールアイテム取得スクリプトとなります。  
処理は.NetFramework OutlookAPIを利用します。  
> 現状はOutlookオブジェクトのみとなります。
  
実行時、Powershellセキュリティポリシー等にて実行できない場合は以下実行方式で使用が可能です。

> `powershell
> powershell -ExecutionPolicy RemoteSigned ./ps_officetools.ps1
> `