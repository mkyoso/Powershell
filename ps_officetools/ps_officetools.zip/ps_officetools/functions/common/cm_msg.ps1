function Global:cm_msg{
    Param(
        $message
    )
    Write-Host $message
}