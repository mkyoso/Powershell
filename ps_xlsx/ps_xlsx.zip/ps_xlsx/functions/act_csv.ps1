﻿#########################################################
### CSVファイル整形/出力処理
<#
　■ 本スクリプトはメインファイルである「」から実行されます。
　　 本処理では"Import-Csv"ではなく"Get-Content"によりテキストファイル整形処理を実施します。
　　 "Import-Csv"ではない理由として対象ファイルにヘッダーが無いためデータオブジェクトの格納が正常に行えないことからテキスト整形処理となっています。
　　 また、整形後ファイルを事前に作成しているのは"Get-Content"系処理がRead Lockする関係上、複数処理中にプロセス重複が発生することを抑止するためとなります。

#>

function Global:act_csv{
    param(
        [String]
        $fs_name,
        $after_fs,
        $dt
    )
    # 処理変数
    $dir = $after_fs
    $result =@()
    ## 実行部
    # 作業ドライブへ移動(ネットワークドライブパス対策)
    cd X:

    # 整形ファイル生成
    New-item $dir -ItemType File
    # 整形元ファイル読み込み+整形ファイル出力
    $data = Get-Content $fs_name -Encoding Default | % {$_ + ",${dt}"} | Out-File $dir -Append -Encoding default 
    
    ## ファイル比較処理
    #  整形前ファイルと整形後ファイルのDiff出力処理
    Compare-Object -ReferenceObject @(Get-Content $fs_name) -DifferenceObject @(Get-Content $dir) | Select-Object -Property @{Name = "ReadCount"; Expression = {$_.InputObject.ReadCount}}, * | Sort-Object -Property ReadCount 
}