﻿#########################################################
### ログ処理フッター出力処理
<#
　本ファンクションは
#>

function Global:cm_footer{
    param(
        [String]
        $message
    )
    $msg_ary = @(
        "--------------------",
        "$($message):Stop",
        "StopTime:$(Get-Date)",
        "====================="
    )
    foreach($msg in $msg_ary){
        Write-Host $msg
    }
}